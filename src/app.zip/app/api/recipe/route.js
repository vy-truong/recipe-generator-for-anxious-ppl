import OpenAI from "openai";

//api container 
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

//Instead of running on one big server far away, the code runs on smaller servers closer to the user
export const runtime = "edge"; // optional for faster response, serverless layer

export async function POST(req) {
  try {
    const { message } = await req.json();

    const response = await openai.chat.completions.create({
        model: "gpt-5", 
        messages: [
            {
            role: "system",
            content: "You are a helpful AI chef who helps users create recipes from ingredients.",
            },
            { role: "user", content: message },
        ],
    });

    //Formats the AI’s answer into JSON and sends it back to frontend.
    // When two computers talk, they can’t just “say” text. They must exchange structured data (JSON).
    //If anything breaks (like a missing key or network failure), 
    // it catches the error and sends a readable message instead of crashing.
    return new Response(
      JSON.stringify({
        reply: response.choices[0].message.content,
      }),
      { headers: { "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error(error);
    return new Response(
      JSON.stringify({ error: error.message || "Something went wrong" }),
      { status: 500, headers: { "Content-Type": "application/json" } }
    );
  }
}
